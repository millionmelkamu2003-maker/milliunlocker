</div>
<footer class="footer">© <?= date('Y') ?> Milli Unlocker. All rights reserved.</footer>
</main>
</div>
</body>
</html>
