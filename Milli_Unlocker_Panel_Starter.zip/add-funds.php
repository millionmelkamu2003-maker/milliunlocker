<?php
require __DIR__ . '/includes/bootstrap.php'; require_login();
$pageTitle='Add Funds'; require __DIR__.'/includes/header.php';
?>
<div class="section-head"><div><span class="eyebrow">ACCOUNT WALLET</span><h2>Add funds</h2></div></div>
<div class="notice-card"><h3>Payment integration is not active yet</h3><p>Before accepting deposits, the administrator must configure verified payment instructions or connect a trusted payment provider. Do not send money to unverified accounts.</p><p>Supported methods planned: CBE, Awash and Telebirr.</p></div>
<?php require __DIR__.'/includes/footer.php'; ?>
