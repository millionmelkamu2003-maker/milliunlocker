<?php
require __DIR__ . '/includes/bootstrap.php'; require_login();
$stmt=$pdo->prepare('SELECT o.id,o.status,o.created_at,s.name AS service_name,s.price FROM orders o LEFT JOIN services s ON s.id=o.service_id WHERE o.user_id=? ORDER BY o.id DESC');
$stmt->execute([$_SESSION['user_id']]); $orders=$stmt->fetchAll();
$pageTitle='My Orders'; require __DIR__.'/includes/header.php';
?>
<?php if(isset($_GET['created'])): ?><div class="success">Order keessan galmaa'eera. Admin processing eegaa.</div><?php endif; ?>
<div class="section-head"><div><span class="eyebrow">ORDER MANAGEMENT</span><h2>Your orders</h2></div><a class="btn primary" href="services.php">Browse services</a></div>
<div class="table-card"><table><thead><tr><th>ORDER ID</th><th>SERVICE</th><th>PRICE</th><th>STATUS</th><th>DATE</th></tr></thead><tbody>
<?php if(!$orders): ?><tr><td colspan="5" class="empty">You have not placed any orders yet.</td></tr><?php endif; ?>
<?php foreach($orders as $o): ?><tr><td>#<?= (int)$o['id'] ?></td><td><?= e($o['service_name'] ?? 'Service') ?></td><td><?= number_format((float)$o['price'],2) ?></td><td><span class="status"><?= e(ucfirst($o['status'])) ?></span></td><td><?= e($o['created_at']) ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php require __DIR__.'/includes/footer.php'; ?>
