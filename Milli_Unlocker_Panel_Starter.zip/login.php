<?php
require __DIR__ . '/includes/bootstrap.php';
if (!empty($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare('SELECT id, password_hash FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $account = $stmt->fetch();
    if ($account && password_verify($password, $account['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$account['id'];
        header('Location: dashboard.php'); exit;
    }
    $error = 'Email yookaan password sirrii miti.';
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login | Milli Unlocker</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth-body"><div class="auth-wrap"><div class="auth-brand"><span class="brand-mark">M</span><div><strong>MILLI UNLOCKER</strong><small>GSM SERVICE PLATFORM</small></div></div>
<section class="auth-card"><span class="eyebrow">WELCOME BACK</span><h1>Sign in to your panel</h1><p class="muted">Manage your services and orders in one place.</p>
<?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?><label>Email address</label><input type="email" name="email" required autocomplete="email"><label>Password</label><input type="password" name="password" required autocomplete="current-password"><button class="btn primary full">Sign In</button></form>
<p class="auth-bottom">New customer? <a href="register.php">Create an account</a></p></section><p class="auth-copy">FAST • SECURE • TRUSTED</p></div></body></html>
