<?php
require __DIR__ . '/includes/bootstrap.php'; require_login();
$user = current_user($pdo);
$stmt = $pdo->prepare('SELECT COUNT(*) FROM orders WHERE user_id = ?'); $stmt->execute([$user['id']]); $orderCount = (int)$stmt->fetchColumn();
$stmt = $pdo->prepare('SELECT COUNT(*) FROM orders WHERE user_id = ? AND status = ?'); $stmt->execute([$user['id'],'pending']); $pendingCount = (int)$stmt->fetchColumn();
$recent = $pdo->prepare('SELECT o.id,o.status,o.created_at,s.name AS service_name FROM orders o LEFT JOIN services s ON s.id=o.service_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 5'); $recent->execute([$user['id']]); $orders = $recent->fetchAll();
$pageTitle='Dashboard'; require __DIR__.'/includes/header.php';
?>
<div class="welcome-banner"><div><span class="eyebrow light">YOUR GSM WORKSPACE</span><h2>Welcome, <?= e($user['name']) ?>!</h2><p>Everything you need to manage your service orders, in one place.</p></div><div class="banner-orb">MU</div></div>
<div class="stat-grid"><div class="stat-card"><span>ACCOUNT BALANCE</span><strong><?= number_format((float)$user['balance'],2) ?></strong><small>Account currency to be configured</small></div><div class="stat-card"><span>TOTAL ORDERS</span><strong><?= $orderCount ?></strong><small>All your submitted orders</small></div><div class="stat-card"><span>PENDING ORDERS</span><strong><?= $pendingCount ?></strong><small>Waiting for processing</small></div></div>
<div class="section-head"><div><span class="eyebrow">ACTIVITY</span><h2>Recent orders</h2></div><a class="text-link" href="orders.php">View all →</a></div>
<div class="table-card"><table><thead><tr><th>ORDER ID</th><th>SERVICE</th><th>STATUS</th><th>DATE</th></tr></thead><tbody>
<?php if (!$orders): ?><tr><td colspan="4" class="empty">No orders yet. Browse Services to get started.</td></tr><?php endif; ?>
<?php foreach($orders as $o): ?><tr><td>#<?= (int)$o['id'] ?></td><td><?= e($o['service_name'] ?? 'Service') ?></td><td><span class="status"><?= e(ucfirst($o['status'])) ?></span></td><td><?= e($o['created_at']) ?></td></tr><?php endforeach; ?>
</tbody></table></div>
<?php require __DIR__.'/includes/footer.php'; ?>
