<?php
require __DIR__ . '/includes/bootstrap.php'; require_login();
$user=current_user($pdo);
if (($user['role'] ?? '') !== 'admin') { http_response_code(403); exit('Access denied.'); }
$users=(int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$orders=(int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$services=(int)$pdo->query('SELECT COUNT(*) FROM services')->fetchColumn();
$pageTitle='Admin Panel'; require __DIR__.'/includes/header.php';
?>
<div class="section-head"><div><span class="eyebrow">CONTROL CENTER</span><h2>Administration overview</h2><p class="muted">Starter admin overview. Service editing, order processing and payment verification are next development stages.</p></div></div>
<div class="stat-grid"><div class="stat-card"><span>REGISTERED USERS</span><strong><?= $users ?></strong></div><div class="stat-card"><span>ALL ORDERS</span><strong><?= $orders ?></strong></div><div class="stat-card"><span>ACTIVE SERVICES</span><strong><?= $services ?></strong></div></div>
<div class="notice-card"><h3>Admin access is active</h3><p>Next we will add secure service management, order status updates, payment verification, API provider settings and audit logs.</p></div>
<?php require __DIR__.'/includes/footer.php'; ?>
