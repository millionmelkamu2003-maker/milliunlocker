<?php
require __DIR__ . '/includes/bootstrap.php'; require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: services.php'); exit; }
verify_csrf();
$serviceId = filter_input(INPUT_POST,'service_id',FILTER_VALIDATE_INT);
$stmt=$pdo->prepare('SELECT id FROM services WHERE id=? AND active=1'); $stmt->execute([$serviceId]);
if (!$stmt->fetch()) { header('Location: services.php'); exit; }
$stmt=$pdo->prepare("INSERT INTO orders (user_id,service_id,status) VALUES (?,?, 'pending')");
$stmt->execute([$_SESSION['user_id'],$serviceId]);
header('Location: orders.php?created=1'); exit;
