<?php
// Copy this file to config.php and enter your cPanel MySQL details.
return [
    'db_host' => 'localhost',
    'db_name' => 'YOUR_CPANEL_DATABASE',
    'db_user' => 'YOUR_CPANEL_DB_USER',
    'db_pass' => 'YOUR_DATABASE_PASSWORD',
    'app_name' => 'Milli Unlocker',
    'base_url' => 'https://panel.milliunlocker.com',
];
