<?php
require __DIR__ . '/includes/bootstrap.php'; require_login();
$user=current_user($pdo); $pageTitle='My Profile'; require __DIR__.'/includes/header.php';
?>
<div class="profile-card"><div class="avatar large"><?= e(strtoupper(substr($user['name'],0,1))) ?></div><h2><?= e($user['name']) ?></h2><p><?= e($user['email']) ?></p><p><span class="status"><?= e(ucfirst($user['role'])) ?></span></p><small class="muted">Member since <?= e($user['created_at']) ?></small></div>
<?php require __DIR__.'/includes/footer.php'; ?>
