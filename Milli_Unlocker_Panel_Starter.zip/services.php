<?php
require __DIR__ . '/includes/bootstrap.php'; require_login();
$services = $pdo->query("SELECT id,name,description,price FROM services WHERE active=1 ORDER BY name")->fetchAll();
$pageTitle='Services'; require __DIR__.'/includes/header.php';
?>
<div class="section-head"><div><span class="eyebrow">SERVICE CATALOG</span><h2>Available services</h2><p class="muted">Choose a service to request. Prices and availability are managed by the administrator.</p></div></div>
<div class="service-grid"><?php foreach($services as $s): ?><article class="service-card"><div class="service-icon">✦</div><h3><?= e($s['name']) ?></h3><p><?= e($s['description']) ?></p><strong><?= number_format((float)$s['price'],2) ?></strong><form method="post" action="place-order.php"><?= csrf_field() ?><input type="hidden" name="service_id" value="<?= (int)$s['id'] ?>"><button class="btn primary">Place order</button></form></article><?php endforeach; ?>
<?php if (!$services): ?><div class="empty-card">Services will appear here after the administrator adds them.</div><?php endif; ?></div>
<?php require __DIR__.'/includes/footer.php'; ?>
