<?php
$pageTitle = $pageTitle ?? 'Dashboard';
$user = current_user($pdo);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> | Milli Unlocker</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="app-shell">
<aside class="sidebar">
  <a class="brand" href="dashboard.php"><span class="brand-mark">M</span><span>MILLI <b>UNLOCKER</b><small>GSM SERVICE PLATFORM</small></span></a>
  <div class="nav-label">WORKSPACE</div>
  <a class="nav-link" href="dashboard.php">▦ <span>Dashboard</span></a>
  <a class="nav-link" href="services.php">▤ <span>Services</span></a>
  <a class="nav-link" href="orders.php">◷ <span>My Orders</span></a>
  <a class="nav-link" href="add-funds.php">＋ <span>Add Funds</span></a>
  <div class="nav-label">ACCOUNT</div>
  <a class="nav-link" href="profile.php">◎ <span>My Profile</span></a>
  <?php if (($user['role'] ?? '') === 'admin'): ?>
  <div class="nav-label">ADMINISTRATION</div>
  <a class="nav-link" href="admin.php">⚙ <span>Admin Panel</span></a>
  <?php endif; ?>
  <a class="nav-link logout" href="logout.php">↪ <span>Sign out</span></a>
  <div class="sidebar-foot">FAST • SECURE • TRUSTED</div>
</aside>
<main class="main-area">
<header class="topbar">
  <div><span class="eyebrow">MILLI UNLOCKER / PANEL</span><h1><?= e($pageTitle) ?></h1></div>
  <div class="top-user"><span class="avatar"><?= e(strtoupper(substr($user['name'] ?? 'U',0,1))) ?></span><span><?= e($user['name'] ?? 'User') ?></span></div>
</header>
<div class="content">
