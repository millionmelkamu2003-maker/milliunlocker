<?php
require __DIR__ . '/includes/bootstrap.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    if (strlen($name) < 2 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 10) {
        $error = 'Maqaa, email sirrii fi password yoo xiqqaate qubee 10 qabu galchi.';
    } else {
        try {
            $stmt = $pdo->prepare('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)');
            $stmt->execute([$name,$email,password_hash($password, PASSWORD_DEFAULT)]);
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$pdo->lastInsertId();
            header('Location: dashboard.php'); exit;
        } catch (PDOException $e) { $error = 'Email kanaan account duraan jiraachuu danda’a.'; }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Create Account | Milli Unlocker</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth-body"><div class="auth-wrap"><div class="auth-brand"><span class="brand-mark">M</span><div><strong>MILLI UNLOCKER</strong><small>GSM SERVICE PLATFORM</small></div></div>
<section class="auth-card"><span class="eyebrow">JOIN MILLI UNLOCKER</span><h1>Create your account</h1><p class="muted">Start managing your GSM service orders.</p>
<?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?><label>Full name</label><input name="name" required maxlength="100"><label>Email address</label><input type="email" name="email" required><label>Password (10+ characters)</label><input type="password" name="password" minlength="10" required><button class="btn primary full">Create Account</button></form>
<p class="auth-bottom">Already registered? <a href="login.php">Sign in</a></p></section><p class="auth-copy">FAST • SECURE • TRUSTED</p></div></body></html>
