MILLI UNLOCKER — STARTER PANEL
================================

This is a starter PHP/MySQL project for panel.milliunlocker.com.

INSTALLATION IN CPANEL
1. Open cPanel > Domains (or Subdomains) and create:
   panel.milliunlocker.com
   Set its document root to a new folder, e.g. public_html/panel.
2. Open cPanel > MySQL Database Wizard.
   Create a database and database user. Add the user to the database with ALL PRIVILEGES.
3. Open phpMyAdmin, select the new database, choose Import, and import database.sql.
4. Upload the contents of this ZIP into the subdomain document root.
5. Rename config.example.php to config.php.
6. Edit config.php with the exact database name, username and password from cPanel.
7. Visit https://panel.milliunlocker.com/register.php and create your own account.
8. In phpMyAdmin run:
   UPDATE users SET role='admin' WHERE email='YOUR_EMAIL_ADDRESS';
   Replace the email with the account you created.
9. Sign in again. The Admin Panel link will appear.

IMPORTANT SECURITY NOTES
- Enable SSL/HTTPS in cPanel before using the site.
- Use a strong, unique database password.
- Delete or rename config.example.php after setup.
- Do not share config.php, database passwords, hosting passwords, or API keys.
- This starter does not yet process real payments or call external GSM APIs.
- Add real payment/API integrations only after confirming provider documentation,
  account ownership, permissions, callback verification and transaction security.
- Keep PHP and MySQL supported and updated; take backups before updates.

CURRENT STARTER FEATURES
- Customer registration and login
- Password hashing and prepared database queries
- CSRF tokens on POST forms
- Customer dashboard and order history
- Service catalog and basic order submission
- Profile page
- Starter admin overview
- Add-funds placeholder (no real payments accepted)

NEXT DEVELOPMENT STAGE
- Admin service CRUD and order processing
- Secure deposits/payment proof and admin verification
- Provider API integration with encrypted secrets and signed callbacks
- Support tickets, notifications, activity logs and rate limiting
